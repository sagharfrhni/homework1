import java.util.Stack;

public class ExpressionEvaluator {

    public static void main(String[] args) {
        String expression = "x*x+x+x-x*x";
        int x = 2;
        int result = evaluateExpression(expression, x);
        System.out.println("نتیجه: " + result);
    }

    private static int evaluateExpression(String expression, int x) {

        expression = expression.replace("x", String.valueOf(x));


        return evaluate(expression);
    }

    private static int evaluate(String expression) {
        Stack<Integer> values = new Stack<>();
        Stack<Character> operators = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);


            if (Character.isDigit(c)) {
                StringBuilder sb = new StringBuilder();
                while (i < expression.length() && Character.isDigit(expression.charAt(i))) {
                    sb.append(expression.charAt(i++));
                }
                i--;
                values.push(Integer.parseInt(sb.toString()));
            }
           
            else if (c == '+' || c == '-' || c == '*' || c == '/') {
                while (!operators.isEmpty() && hasPrecedence(c, operators.peek())) {
                    values.push(applyOperation(operators.pop(), values.pop(), values.pop()));
                }
                operators.push(c);
            }
        }

        while (!operators.isEmpty()) {
            values.push(applyOperation(operators.pop(), values.pop(), values.pop()));
        }

        return values.pop();
    }

    private static boolean hasPrecedence(char op1, char op2) {
        if (op2 == '*' || op2 == '/') {
            return !(op1 == '*' || op1 == '/');
        }
        return false;
    }

    private static int applyOperation(char op, int b, int a) {
        switch (op) {
            case '+':
                return a + b;
            case '-':
                return a - b;
            case '*':
                return a * b;
            case '/':
                return a / b;
        }
        return 0;
    }
}
