public class Division {
    public static int division(int a, int b) {
        if (b == 0) {
            System.out.println("error");
        }
        if (a < b) {
            return 0;
        }
        return 1 + division(a - b, b);
    }
    public static void main(String[] args) {
        int a = 18;
        int b = 4;
        System.out.println(a + " / " + b + " = " +  division(a, b));
    }
}