import java.util.Scanner;

public class TruthTable {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print(" inter n ");
        int n = scanner.nextInt();
        printTruthTable(n);
    }
    private static void printTruthTable(int n) {
        int rows = (int) Math.pow(2, n);
        for (int i = 0; i < n; i++) {
            System.out.print("P" + (i + 1) + "/");
        }
        System.out.println();

        for (int i = 0; i < rows; i++) {
            for (int j = n - 1; j >= 0; j--) {
                boolean value = (i / (int) Math.pow(2, j)) % 2 == 0;
                System.out.print((value ? "true" : "false") + "/");
            }
            System.out.println();
        }
    }
}
