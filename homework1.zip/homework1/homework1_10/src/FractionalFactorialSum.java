public class FractionalFactorialSum {
    public static double factorial(int n) {
        if (n == 0) {
            return 1.0;
        } else {
            return n * factorial(n - 1);
        }
    }

    public static double seriesSum(int n) {
        if (n == 1) {
            return 1.0;
        } else {
            return 1.0 / factorial(n) + seriesSum(n - 1);
        }
    }

    public static void main(String[] args) {
        int n =4;
        double result = seriesSum(n);
        System.out.println("1/1! + 1/2! + 1/3! + 1/4! + 1/5! + ... + 1/n! = " + result);
    }
}