public class hanoi {
    public static void hanoi(int n, char fromRod, char toRod, char auxRod) {
        if (n == 1) {
            System.out.println("Move disk 1 from rod " + fromRod + " to rod " + auxRod);
            System.out.println("Move disk 1 from rod " + auxRod + " to rod " + toRod);
            return;
        }
        hanoi(n - 1, fromRod, toRod, auxRod);
        System.out.println("Move disk " + n + " from rod " + fromRod + " to rod " + auxRod);
        hanoi(n - 1, toRod, fromRod, auxRod);
        System.out.println("Move disk " + n + " from rod " + auxRod + " to rod " + toRod);
        hanoi(n - 1, fromRod, toRod, auxRod);
    }

    public static void main(String args[]) {
        int n = 2;
        hanoi(n, 'A', 'C', 'B');
    }
}