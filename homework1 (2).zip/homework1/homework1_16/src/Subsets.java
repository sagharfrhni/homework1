public class Subsets {
    public static void findSubsets(int[] nums, int index, int[] current, int len) {
        if (index == nums.length) {
            for (int i = 0; i < len; i++) {
                System.out.print(current[i] + " ");
            }
            System.out.println();
            return;
        }
        current[len] = nums[index];
        findSubsets(nums, index + 1, current, len + 1);
        findSubsets(nums, index + 1, current, len);
    }

    public static void main(String[] args) {
        int[] nums = {1, 2, 3};
        int[] current = new int[nums.length];
        System.out.println("null set");
        findSubsets(nums, 0, current, 0);

    }
}