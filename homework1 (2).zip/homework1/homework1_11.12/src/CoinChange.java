public class CoinChange {

    public static void main(String[] args) {
        int n = 20;
        int[] coins = {2, 5, 10};
        int[] combination = new int[n];
        int[] resultsCount = new int[1];


        findCombinations(n, combination, resultsCount, 0, coins, 0);

        System.out.println("number of combinations:" + resultsCount[0]);
    }

    private static void findCombinations(int remaining, int[] combination, int[] resultsCount, int index, int[] coins, int start) {
        if (remaining == 0) {
            resultsCount[0]++;
            System.out.print("combinations: ");
            for (int i = 0; i < index; i++) {
                System.out.print(combination[i] + " ");
            }
            System.out.println();
            return;
        }

        for (int i = start; i < coins.length; i++) {
            if (remaining >= coins[i]) {
                combination[index] = coins[i];
                findCombinations(remaining - coins[i], combination, resultsCount, index + 1, coins, i);
            }
        }
    }
}
