public class Duplicate{

    public static boolean duplicate(String s) {
        if(s.length()==0)
      return true;
        if (s.length() == 2 && s.charAt(0) == s.charAt(1)) {
            return true;
        }
        if (s.length() % 2 != 0) {
            return false;
        }
            else if (s.length() == 2 && s.charAt(0) != s.charAt(1) ||
        s.length() == 1) {
            return false;
        }
        return (duplicate(s.substring(1,s.length()/2)));
    }
    public static void main(String[] args) {
        System.out.println(duplicate("ALILIALILI"));
        System.out.println(duplicate("HTMMTMMHTMMTMM"));
    }
}