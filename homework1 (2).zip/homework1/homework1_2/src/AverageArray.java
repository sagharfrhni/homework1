public class AverageArray{
    public static double averageArray(int[] arr, int start, int end) {
        if (start == end) {
            return arr[start];
        }

        double Sum = arr[start] + (end - start) * averageArray(arr, start + 1, end);
        double average = Sum / (end - start + 1);
        return average;
    }

    public static void main(String[] args) {
        int[] numbers = {2, 4, 6, 8, 10};
        double average = averageArray(numbers, 0, numbers.length - 1);
        System.out.println("average :" + average);
    }
}