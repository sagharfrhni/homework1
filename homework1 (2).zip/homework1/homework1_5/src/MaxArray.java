public class MaxArray{
    public static int findMax(int[] arr, int start, int end) {
        if (start == end) {
            return arr[start];
        }
        return Math.max(arr[start], findMax(arr, start + 1, end));
    }

    public static void main(String[] args) {
        int[] arr = {3, 7, 2, 12, 1};
        int max = findMax(arr, 0, arr.length - 1);
        System.out.println("Max : " + max);
    }
}